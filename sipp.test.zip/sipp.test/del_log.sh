rm -f *.log
rm -f *.csv

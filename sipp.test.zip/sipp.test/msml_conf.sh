
./sipp -sf caller_msml_conf.xml -i 172.24.130.97:5061 -s 1000 -r 5 -p 11205 -m 6 -l 999999 -t l1 -trace_msg -trace_screen -trace_stat -trace_err -trace_rtt 172.24.130.36:5061

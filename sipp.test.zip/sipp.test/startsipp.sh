
./sipp -sf register.xml -i 172.24.134.160 172.24.131.28:5060 -r 50 -l 999999999 -t t1 -timeout 43200 -trace_screen -bg 
./sipp -sf register2.xml -i 172.24.134.160 172.24.131.29:5060 -r 50 -l 999999999 -t t1 -timeout 43200 -trace_screen -bg


#!/bin/bash

while :
do

env LD_LIBRARY_PATH=$LD_LIBRARY_PATH:. ./sipp -sf Gir_Agent.xml -p 8095 172.24.131.39:5070 -i 172.24.131.34 -slave s1 -slave_cfg performance_ms.txt -trace_screen -bg

env LD_LIBRARY_PATH=$LD_LIBRARY_PATH:. ./sipp -sf Gir_Caller.xml -p 9085 172.24.131.39:5070 -i 172.24.131.34 -master m -slave_cfg performance_ms.txt -r 8 -trace_screen -bg

sleep 300

killall -9 sipp

done


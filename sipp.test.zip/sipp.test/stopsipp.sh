
killall -SIGUSR2 sipp
killall -9 sipp
